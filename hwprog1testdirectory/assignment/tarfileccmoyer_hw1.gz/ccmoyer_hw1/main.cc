
#include <iostream>
using std::cout;
using std::endl;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Christopher Moyer. All rights reserved.
 * Date: 27 August 2018
**/

int main(int argc, char *argv[]) {
  cout << "Hello, world." << endl;
  cout << "My name is Christopher Moyer." << endl;

  return 0;
}

